<?php
    //Primer Numero Cambios Grandes
    //Segundo Numero Cambios Menores
    //Tercer Numero Parches
    $currentVersion = '0.5.1';
    $updateController = 'http://blabell.xyz/Landery/versionControl.txt';
    $updateRepository = 'http://blabell.xyz/Landery/app.zip';
    $changeLogController = 'http://blabell.xyz/Landery/changelog.json'
?>