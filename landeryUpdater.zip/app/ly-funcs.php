<?php
    //Obtiene y guarda los datos del JSON
    function getJSON($JSONPath){
        $contents = file_get_contents($JSONPath);
        return json_decode($contents, true);
    }

    function printJSON($JSONRow, $JSONValue){
        $contentsDecoded = $GLOBALS["contentsDecoded"];

        if($JSONRow == ''){
            $print = $contentsDecoded[0][$JSONValue];
        }
        elseif($JSONRow != ''){
            $print = $contentsDecoded[$JSONRow][$JSONValue];
        }
        
        echo $print;
    }

    function editJSON($editValue, $IsMultiline)
    {
        $contentsDecoded = $GLOBALS["contentsDecoded"];
        $toEdit = $_POST[$editValue];
        if($IsMultiline == true)
        {
            $toEdit = preg_replace('/\s*$^\s*/m', "\n", $toEdit);
        }       
        return $toEdit;        
    }

    function displayer($pageNumber, $var, $arrayElement = null)
    {
        $displayer = $GLOBALS["displayer"];

        if($arrayElement != null){
            if($arrayElement == 0){
                $arrayElement = 'data';
                echo $displayer[$var.$pageNumber.$arrayElement];
            }
            else{
                echo $displayer[$var.$pageNumber.$arrayElement];
            }
        }
        else{            
            echo $displayer[$var.$pageNumber];
        }
        
    }

    function startLandery(){
        $contentsDecoded = getJSON('config/ly-landing.json');

        $JSONArray = $contentsDecoded[0];    

        $t=0;

        $displayer = [];

        foreach ($JSONArray as $key => $value) {
            foreach ($value as $key2 => $value2) {
                if(is_array($value2)){  
                    for ($i=0; $i < count($value2); $i++) { 
                        $j = $i+1;
                        $id = $key2.$t.$j;
                        ${$id} = $value2[$i];
                        $displayer += [$id => $value2[$i]];
                    }            
                }
                else
                {
                    $id = $key2.$t;
                    ${$id} = $value2;
                    $displayer += [$id => $value2];
                }
            }    
            $t++;
        }

        return $displayer;
    }

    function setLibrary($library, $libraryType){
        if($libraryType == 'js' OR $libraryType = 'javascript' OR $libraryType == 'Javascript' OR $libraryType == 'JS' OR $libraryType == 'Js' OR $libraryType == 'JavaScript'){
            $library ='app/devLib/'.$library.'.js';
            echo '<script src="'.$library.'"></script>';
        }
    }

    function delete_directory($dirname) {
        if (is_dir($dirname))
            $dir_handle = opendir($dirname);
        if (!$dir_handle)
            return false;
        while($file = readdir($dir_handle)) {
            if ($file != "." && $file != "..") {
                if (!is_dir($dirname."/".$file))
                        unlink($dirname."/".$file);
                else
                        delete_directory($dirname.'/'.$file);
            }
        }
        closedir($dir_handle);
        rmdir($dirname);
        return true;
    }

    function deleter($dir, $omitFiles = null) {
        if (is_dir($dir)) {
          $objects = scandir($dir);
          foreach ($objects as $object) {
            if(!in_array($object, $omitFiles)){
                if ($object != "." && $object != "..") {
                    if (filetype($dir."/".$object) == "dir") {
                        delete_directory($dir."/".$object); 
                    }               
                    else{
                      unlink($dir."/".$object);
                    }
                }
            }            
          }
        }
    }

    function errorMss($mss){
        echo '<style>    
        .main{
            width: 100%;
            height: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: -80px;
        }
    
        .wrap{
            display: flex;
            flex-direction: column;
            align-items: center;
        }
    
        .wrap>span{
            font-size: 100pt;
            color: red;
            margin-bottom: 30px;
        }
    
        .wrap>h3{
            font-size: 20pt;
            text-align: center;
        }
    </style>
    <div class="main">
        <div class="wrap">
            <span class="icon-alert-triangle"></span>
            <h3>'.$mss.'</h3>
        </div>
    </div>';
    }

    function get_client_ip() {
        $ipaddress = '';
        if (isset($_SERVER['HTTP_CLIENT_IP']))
            $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
        else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
            $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
        else if(isset($_SERVER['HTTP_X_FORWARDED']))
            $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
        else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
            $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
        else if(isset($_SERVER['HTTP_FORWARDED']))
            $ipaddress = $_SERVER['HTTP_FORWARDED'];
        else if(isset($_SERVER['REMOTE_ADDR']))
            $ipaddress = $_SERVER['REMOTE_ADDR'];
        else
            $ipaddress = 'UNKNOWN';
        return $ipaddress;
    }
    
    function landeryAnalytics(){
        session_start();
    
        $currentIp = get_client_ip();
        $visitSession = '';

        $analyticsFile = '../app/registrations/lyAnalytics.json';
    
        if(isset($_SESSION['visitIp'])){
            $visitSession = $_SESSION['visitIp'];
        }else
        { 
            $_SESSION['visitIp'] = $currentIp;
        }
    
        $json = file_get_contents($analyticsFile);
        $json = json_decode($json, true);
        
        $date = date('d/m/y');
        
        if($currentIp != $visitSession){
            if(array_key_exists($date, $json)) {
                $visits = $json[$date];
                $visits++;
            
                $json[$date] = $visits;
                $newJson = json_encode($json);
            
                file_put_contents($analyticsFile, $newJson);
            }
            else{
                $json[$date] = 0;
                $newJson = json_encode($json);
                file_put_contents($analyticsFile, $newJson);
            
                $visits = $json[$date];
                $visits++;
            
                $json[$date] = $visits;
                $newJson = json_encode($json);
            
                file_put_contents($analyticsFile, $newJson);
            }
    
            $_SESSION['visitIp'] = $currentIp;
        }    
        else{
            if(array_key_exists($date, $json)) {
                $visits = $json[$date];
            }
            else{
                $json[$date] = 0;
                $newJson = json_encode($json);
                file_put_contents($analyticsFile, $newJson);
            
                $visits = $json[$date];
                $visits++;
            
                $json[$date] = $visits;
                $newJson = json_encode($json);
            
                file_put_contents($analyticsFile, $newJson);
            }
        }
    }

    function blabellAnalytics()
    {        
        $analyticsFile = '../app/registrations/lyAnalytics.json';

        $oldVisits = file_get_contents($analyticsFile);
        $oldVisits = json_decode($oldVisits, true);

        $earlyDays = [];
        $visitDay = date('d');

        for ($i=0; $i < $visitDay; $i++) { 
            $j = $i+1;
            array_push($earlyDays, '0');
        }

        for ($i=0; $i < $visitDay; $i++) { 
            $earlyDays[$i] = rand(0,100);
        }

        $visitDay--;

        echo $visitDay;

        print_r($earlyDays);

        $earlyDays = json_encode($earlyDays);
            
        file_put_contents($analyticsFile, $earlyDays);
    }