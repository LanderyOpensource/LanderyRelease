<?php
    $array = ["0", "1", "2", "2"];
?>
<style>
    main[role="pager"] {
        width: 100%;
        box-sizing: border-box;
        padding: 40px;
    }

    canvas {
        width: 100%;
    }

    .chart {
        z-index: 10;
    }

    main[role="pager"]>h1 {
        font-weight: 300;
        margin-bottom: 30px;
        font-size: 25pt;
    }

    main[role="pager"]>h2 {
        font-weight: 300;
        margin-bottom: 15px;
        font-size: 20pt;
    }
</style>
<main role="pager">
    <h1>Estadisticas Generales</h1>
    <h2>Visitas mensuales</h2>
    <canvas id="canvas"></canvas>
    <h1 id="demo"></h1>
</main>
<script type="text/javascript">
    var oldIndex = [];

    let year = new Date().getFullYear();
    let month = new Date().getMonth();

    month++;

    var getDaysInMonth = function(month, year) {
        return new Date(year, month, 0).getDate();
    };

    let fullDays = getDaysInMonth(month, year);

    let days = [];

    for (index = 0; index < fullDays; index++) {
      j = index + 1;
      days.push(j);
    } 

    function removeData(chart) {
        chart.data.dataset[0].data.pop();
        chart.data.dataset[0].data.update();
    }

    function clearData(){
        $.getJSON( "registrations/lyAnalytics.json", function( data){             
            for (x in data) { 
                chart.data.datasets[0].data.pop(); 
                chart.update();
            }
        });
    }

    function updateData(){
        clearData()
        $.getJSON( "registrations/lyAnalytics.json", function( data){             
            for (x in data) { 
                oldIndex.push(data[x]);
                chart.data.datasets[0].data.push(data[x]);                
                chart.update();
            }
        });
    }

    updateData()

    setInterval( "updateData()", 3000);

    var ctx = document.getElementById('canvas').getContext('2d');
    var chart = new Chart(ctx, {
        // The type of chart we want to create
        type: 'line',

        // The data for our dataset
        data: {
            labels: days,
            datasets: [{
                label: 'My First dataset',
                borderColor: '#e65100',
                fill: '',
                data: []
            }]
        },
        options: {
            legend: {
                display: false,
            },
            tooltips: {
                mode: 'index',
                intersect: false,
            },
            hover: {
                mode: 'nearest',
                intersect: true
            },
            animation: {
                duration:0
            },
            scales: {
                xAxes: [{
                    display: true,
                    scaleLabel: {
                        display: true,
                        labelString: 'Días'
                    }
                }],
                yAxes: [{
                    display: true,
                    scaleLabel: {
                        display: true,
                        labelString: 'Visitas'
                    }
                }]
            }            
        }
    });
</script>