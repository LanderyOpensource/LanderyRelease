<div class="alert">
    <h1>Hay una nueva actualización disponible.</h1>
    <a href="?page=updater">Descargar desde la pagina oficial</a>
</div>