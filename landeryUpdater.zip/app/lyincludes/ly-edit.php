<?php

$contentsDecoded = getJSON('../landing/config/ly-landing.json');

$JSONArray = $contentsDecoded[0];

$t = 0;
$d = 0;
?>

<form action="" method="post" class="frmEdit">
    <?php
        foreach ($JSONArray as $key => $value) {
            echo "<li><h2>Página $key</h2></li>";
            foreach ($value as $key => $value) {
                if (is_array($value)) {
                    echo "<li>$key</li>";
                    for ($i = 0; $i < count($value); $i++) {
                        $id = $t . $key . $i;
                        $j = $i + 1;
                        echo '<input type="text" placeholder="Valor ' . $j . '" name="' . $id . '" value="' . $value[$i] . '">';
                    }
                } else {
                    if (strpos($key, 'Description') === false) {
                        echo '<input type="text" placeholder="' . $key . '" name="' . $t . $key . '" value="' . $value . '">';
                    } else {
                        echo '<textarea placeholder="Multilinea" name="' . $t . $key . '">' . $value . '</textarea>';
                    }
                }
            }
            $t++;
        }
    ?>
    <input type="submit" value="Editar" name="save">
</form>