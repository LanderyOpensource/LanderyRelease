<?php
    require_once 'registrations/credentials.php';

    if(isset($_POST['changeData'])){
        $users = $_POST['user'];
        $passwords = $_POST['password'];

        $cred = '<?php $users='."'".$users."'".'; $passwords='."'".$passwords."'".'; ?>';

        file_put_contents('registrations/credentials.php', $cred);
    }
?>
<style>
    *{
        margin: 0;
        padding: 0;
    }

    .main{
        padding: 0 20px;
    }

    .config{
        width: 100%;
        height: auto;       
        display: flex;
    }

    .config>ul{
        width: 100%;
    }

    .config>ul>li{
        display: flex;
        flex-direction: column;
        width: 100%;
        text-align: left ;
        box-sizing: border-box;
        padding: 5px 30px;      
        border-bottom: solid 2px #2D2E3E;      
        margin-bottom: 0;  
    }

    .config>ul>li[clicker]{
        cursor: pointer;
        transition: .5s;
    }

    .config>ul>li[clicker]:hover{
        background-color: rgba(0, 0, 0, 0.2);
    }

    .config>ul>li>h3,span{
        font-weight: 300;
        user-select: none;
    }

    .popup{
        width: 30%;
        min-width: 300px;
        max-width: 450px;
        min-height: 200px;        
        border-radius: 20px;
        overflow: hidden;        
    }

    .popup>.header{
        background: #2D2E3E;
        height: 50px;
        box-sizing: border-box;
        padding: 0 15px;
        color: white;
        display: flex;
        justify-content: space-between;
        align-items: center;
        -webkit-box-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
        -moz-box-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
        box-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
    }

    .popup>.header>h2{
        font-size: 15pt;
        font-weight: 300;
    }

    .popup>.header>span{
        cursor: pointer;
        color: red;
        font-size: 15pt;
    }

    .popup>.body{
        min-height: calc(200px - 50px);
        box-sizing: border-box;
        padding: 20px;
        background-color: #fafafa;
    }

    input[type="submit"]{
        width: 100%;
    }

    @media (min-width: 1060px) {
        .main{
            padding: 0 60px;
        }
    }
</style>
<div class="main"  id="page">
    <nav class="config">
        <ul>
            <li>
                <h3>Blabell Landery</h3>
                <span>Version: <?php echo $currentVersion; ?></span>
            </li>
            <li clicker onclick="smartModal('userConf')">
                <h3>Cambiar mis datos</h3>
                <span>Usuario: <?php echo $users; ?></span>
            </li>
            <li clicker onclick="smartModal('repos')">
                <h3>Cambiar Repositorio</h3>
                <span>Cambia el repositorio de actualización</span>
            </li>
        </ul>
    </nav>
    <div id="userConf" class="popup" hidden>
        <div class="header">
            <h2>Cambiar datos</h2>
            <span class="icon-x" onclick="closeModal()"></span>
        </div>        
        <div class="body">
            <form action="#" method="post">
                <input type="text" placeholder="<?php echo $users; ?>" name="user">
                <br>
                <input type="password" placeholder="<?php echo $passwords; ?>" name="password">
                <br>
                <input type="submit" value="Cambiar mis datos" name="changeData">
            </form>            
        </div>
    </div>

    <div id="repos" class="popup" hidden>
    <div class="header">
            <h2>Cambiar repositorio de descarga</h2>
            <span class="icon-x" onclick="closeModal()"></span>
        </div>        
        <div class="body">
            <form action="#" method="post">
                <input type="radio" name="blabell" id="blabell" value="Blabell Official Server" checked="checked">Blabell Servers<br>
                <input type="radio" name="blabell" id="github" value="GitHub">Github<br>
                <input type="radio" name="blabell" id="sourceforge" value="Source Forge">Source Forge<br>
                <input type="submit" value="Cambiar mis datos" name="changeData">
            </form>            
        </div>
    </div>
</div>