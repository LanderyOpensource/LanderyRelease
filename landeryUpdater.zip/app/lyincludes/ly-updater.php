<?php   
    $json = file_get_contents($changeLogController);

    $logfile = json_decode($json);
?>
<style>
    *{
        margin: 0;
        padding: 0;
    }

    .main{
        box-sizing: border-box;
        height: 100%;
        width: 100%;
        display: flex;
        flex-direction: column;
        padding: 80px 75px;
        font-weight: 300;
    }

    .modallog{
        width: 100%;
        height: 500px;
        min-height: 430px;
        background-color: #fafafa;
        -webkit-box-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
        -moz-box-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
        box-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
        border-radius: 10px;
        padding: 25px;
        box-sizing: border-box;
        overflow: auto;
    }

    .tcl{
        padding-bottom: 20px;
    }

    .prgbar{
        width:100%;
        margin-right:20px; 
        height: 50px;
        transition: .5s all;
        -webkit-box-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
        -moz-box-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
        box-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
        border-radius: 100px;
        background-color: #BFBFBF;
        overflow: hidden;
    }

    .prgcontrols{
        margin-top: 30px;
        width: 100%;
        display:flex;
        flex-direction: row;
    }

    input[type="submit"]{
        width: 20%;
        font-size: 13pt;
        cursor: pointer;
        transition: .5s all;
    }

    .prgde{
        width: 0%;
        height: 100%;
        background-color: #e65100;
        border-radius:200px;
        transition: .3s;
    }

    .modallog>h2{
        margin-bottom: 25px;
    }

    .line{
        width: 97%;
        border-radius: 200px;
        height: 8px;
        background-color: black;
        margin: 0 auto;
    }

    .changelogcontent{
        width: 100%;
        height: auto;
        min-height: 100px;
        margin-top:20px;
    }
    
    .feature{
        width: 100%;
        display: flex;
        flex-direction: row;
        align-items: center;
        margin: 20px 0;
    }

    .feature>h3{
        font-weight: 300;
    }

    .featuretype{
        padding: 10px 30px;
        color: white;
        border-radius: 100px;
        margin-right:20px;
        width: 100px;
        display: flex;
        justify-content: center;
    }

    .featureadd{
        background-color: #008B50;
    }

    .featureremoved{
        background-color: #D80000;
    }

    .featurechanged{
        background-color: #D88500;
    }

    .featurefixed{
        background-color: #9600D8;
    }

    .main>.noupdater{
        margin-top: 20px;
        text-align: center;
    }
</style>
<script type="text/javascript">
$(document).ready(function () {
    $('#submitButton').click(function () {
    	    $('#uploadForm').ajaxForm({
    	        target: '#outputImage',
				url: 'ly-updateDownload.php',
				dataType: 'JSON',
    	        beforeSubmit: function () {
    	        	  $("#outputImage").hide();
    	        	   if($("#uploadImage").val() == "") {
    	        		   $("#outputImage").show();
    	        		   $("#outputImage").html("<div class='error'>Choose a file to upload.</div>");
                    return false; 
                }
    	            $("#prgbar").css("display", "block");
    	            var percentValue = '0%';

    	            $('#prgde').width(percentValue);
    	            $('#percent').html(percentValue);
    	        },
    	        uploadProgress: function (event, position, total, percentComplete) {

    	            var percentValue = percentComplete + '%';
    	            $("#prgde").animate({
    	                width: '' + percentValue + ''
    	            }, {
    	                easing: "linear",
    	                step: function (x) {
						    percentText = Math.round(x * 100 / percentComplete);
							$("#percent").text(percentValue);
    	                }
    	            });
    	        },    	        
    	        complete: function (xhr) {
    	            if (xhr.responseText != "error")
    	            {
                        console.log(xhr.responseText);
                        console.log('Update was succesfuly installed');                        
                        $("#prgbar").css("width","0px");
                        
                        $("#submitButton").css("width","100%");                         
                        $("#submitButton").val("Restart Landery");  
                        setTimeout(function(){
                            $("#prgbar").css("margin-right","0px");
                        }, 200);
    	            }
    	            else{  
        	            console.warn("Problem in downloading file.");
        	            $("#prgde").stop();
    	            }
    	        }
    	    });
    });
});
</script>
<div class="main"  id="page">
<h1 class="tcl">Change Log</h1>
        <div class="modallog">
            <h2>Version: <?php echo $logfile->version ?></h2>
            <div class="line"></div>
            <div class="changelogcontent">
                <?php                      
                    for ($i=0; $i < count($logfile->add) ; $i++) { 
                        echo"<article class='feature'>
                                <div class='featuretype featureadd'>
                                    <p>Added</p>
                                </div>
                                <h3>" . $logfile->add[$i] . "</h3>
                            </article>";
                    } 
                    for ($i=0; $i < count($logfile->fix) ; $i++) { 
                        echo"<article class='feature'>
                                <div class='featuretype featurefixed'>
                                    <p>Fixed</p>
                                </div>
                                <h3>" . $logfile->fix[$i] . "</h3>
                            </article>";
                    } 
                    for ($i=0; $i < count($logfile->change) ; $i++) { 
                        echo"<article class='feature'>
                                <div class='featuretype featurechanged'>
                                    <p>Change</p>
                                </div>
                                <h3>" . $logfile->change[$i] . "</h3>
                            </article>";
                    }
                    for ($i=0; $i < count($logfile->remove) ; $i++) { 
                        echo"<article class='feature'>
                                <div class='featuretype featureremoved'>
                                    <p>Removed</p>
                                </div>
                                <h3>" . $logfile->remove[$i] . "</h3>
                            </article>";
                    } 
                ?>                               
            </div>
        </div> 
    <?php if ($currentVersion != $newVersion): ?>              
        <form action="ly-updateDownload.php" id="uploadForm" name="frmupload" method="post" enctype="multipart/form-data">
            <div class="prgcontrols">
                <div class="prgbar" id="prgbar">
                    <div class="prgde" id="prgde"></div>
                </div>
                <input id="submitButton" type="submit" name='btnSubmit' value="Submit Image" >
                <input ttype="text" id="uploadImage" name="uploadImage" value="<?php echo $updateRepository ?>" style="display:none;" >
            </div>
        </form>
        <div style="height: 10px;"></div>
        <div id='outputImage'></div>
    <?php else: ?>
        <h1 class="noupdater">No hemos encontrado actualizaciónes</h1>
    <?php endif; ?>
</div>