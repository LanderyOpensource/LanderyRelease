<?php
if (isset($_POST['btnSubmit'])) {

    $url = $_POST['uploadImage'];

    $urlArray = explode("/", $url);
    $fileName = end($urlArray);
    $fileArray = explode(".", $fileName);
    $extension = end($fileArray);

    $message = "Starting Download";
    $message = "Downloading Update";
    $fileData = file_get_contents($url);
    $newPath = 'temp/app.'. $extension;;
    $message = "Saving file";
    file_put_contents($newPath, $fileData);

    // assuming file.zip is in the same directory as the executing script.
    $file = 'temp/app.'. $extension;
    $message = "Installing Update";

    if($extension == 'zip'){
        // get the absolute path to $file
    $path = pathinfo(realpath($file), PATHINFO_DIRNAME);

    $zip = new ZipArchive;
    $res = $zip->open($file);
    if ($res === TRUE) {
        // extract it to the path we determined above
        $zip->extractTo(__DIR__);
        $zip->close();
        $message = "WOOT! $file extracted to $path";
    } else {
        $message = "Doh! I couldn't open $file";
    }
    }
        
}
?>