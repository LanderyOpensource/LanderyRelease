<?php
    session_start();

    require_once 'ly-funcs.php';
    require_once 'registrations/app.php';

    if(isset($_GET['page'])){
        $page = $_GET['page'];  
    }    

    $t=0;
    $d=0;

    $versionState;

    $newVersion = file_get_contents($updateController);

    if($_SESSION['sessionStarted'] == false){
        header("Location:ly-admin.php");
    }   

    $contentsDecoded = getJSON('../landing/config/ly-landing.json');

    $JSONArray = $contentsDecoded[0];    

    if(isset($_POST['exit'])){
        $_SESSION['sessionStarted'] = false;
        header("Location:index.php");
    }

    if(isset($_POST['save'])){
        foreach ($JSONArray as $key => $value) {
            foreach ($value as $key2 => $value2) {
                if(is_array($value2)){
                    for ($i=0; $i < count($value2); $i++) { 
                        $result = $_POST[$d.$key2.$i];
                        $contentsDecoded[0][$key][$key2][$i] = $result;                        
                    }                    
                }
                else{
                    $result = $_POST[$d.$key2];
                    $contentsDecoded[0][$key][$key2] = $result;
                }
            }
            $d++;      
        }

        $json = json_encode($contentsDecoded);
        file_put_contents('../landing/config/ly-landing.json', $json);

        header("Refresh:0");

        echo 'Los parametros se han modificado correctamente';
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400" rel="stylesheet">
    <link rel="stylesheet" href="icons/style.css">
    <script src="https://code.jquery.com/jquery-3.3.1.min.js" type="text/javascript"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.8.0"></script>
    <script src="//cdn.jsdelivr.net/chartist.js/latest/chartist.min.js"></script>
    <script type="text/javascript" src="lyDev/jquery.form.min.js"></script>
    <script src="lyDev/hmenu.js"></script>
    <script src="lyDev/smartModal.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="ly-css.css">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Landery Admin</title>
</head>
<body>
    <header>
        <div class="hside">
            <span class="icon-menu" id="hbtn"></span>
            <h1>Landery</h1>
        </div>        
        <form action="" method="post">
            <input type="submit" value="Cerrar Sesión" name="exit" class="header">
            <button name="exit" class="iconLogout" value=""><span class="icon-log-out iconLogout"></span></button>
        </form>
    </header>
    <div class="sidebar" id="hnav">
        <nav>
            <ul>
                <li><a href="?page=edit"><span class="icon-edit-2"></span>Editar</a></li>
                <li><a href="?page=updater"><span class="icon-refresh-cw"></span>Updater</a></li>
            </ul>
            <ul>
                <li><a href="?page=config"><span class="icon-settings"></span>Configuración</a></li>
            </ul>
        </nav>
    </div>
    <main role="mainContainer">
        <?php                
            if(isset($page)){
                if($page != 'updater')
                {
                    if ($currentVersion != $newVersion) {
                        include_once 'lyincludes/ly-versionAlert.php';
                    }
                }

                switch ($page) {
                    case null:
                        include_once 'lyincludes/ly-edit.php';
                        break;
    
                    case 'edit':
                        include_once 'lyincludes/ly-edit.php';
                        break;
    
                    case 'config':
                        include_once 'lyincludes/ly-config.php';
                        break;

                    case 'updater':
                        include_once 'lyincludes/ly-updater.php';
                        break;

                    default:
                        errorMss("No encontramos la página");
                        break;
                }
                                  
            }
            else{
                include_once 'lyincludes/ly-edit.php';
            }            
        ?>
    </main>
</body>
</html>
