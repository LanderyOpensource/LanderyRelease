<?php
    session_start();

    if(isset($_SESSION['sessionStarted'])){
        if($_SESSION['sessionStarted'] == true){
            header("Location:ly-admin.php");
        }
    }    

    require_once 'registrations/credentials.php';   

    if(isset($_POST['login'])){
        $gettedUser = $_POST['username'];
        $gettedPassword = $_POST['password'];
        $gettedUser = htmlspecialchars($gettedUser);
        $gettedPassword = htmlspecialchars($gettedPassword);
        if($users == $gettedUser && $passwords == $gettedPassword){
            $_SESSION['sessionStarted'] = true;
            header("Location:ly-admin.php");
        }
        else{
            echo 'Nombre de usuario o contraseña incorrecta';
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400" rel="stylesheet">
    <link rel="stylesheet" href="icons/style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="ly-css.css">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Landery - Login</title>
</head>
<body>
    <header class="h1Login">
        <h1>Landery</h1>
    </header>
    <form action="#" method="post" class="fmrLogin">
        <input type="text" placeholder="Usuario" name="username">
        <input type="password" placeholder="Contraseña" name="password">

        <input type="submit" value="Ingresar" name="login">
    </form>
</body>
</html>