$(document).ready(hmenu);


/*
var btn = document.getElementById('hbtn');
var nav = document.getElementById('hnav');
*/  

function hmenu() {      
    var isVisible = false;   
    var nav = document.getElementById('hnav');  

    $('#hbtn').click(function () { 
        if(isVisible == false){
            isVisible = true;    
            $('#hnav').animate({
                left: '0px'
            });       
        }
        else{
            isVisible = false;    
            $('#hnav').animate({
                left: '-100%'
            });        
        }
    });
}

$( window ).on( "orientationchange", function( event ) {
    isVisible = true;    
    $('#hnav').animate({
        left: '0px'
    });  
});