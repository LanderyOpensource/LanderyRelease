function smartModal(modalId) {
    let modal = document.getElementById(modalId);

    var modalBackground = document.createElement('div');
    modalBackground.setAttribute('class', 'smBacker');
    modalBackground.style.position = "fixed";
    modalBackground.style.height = "calc(100% - 80px)";
    modalBackground.style.width = "100%";
    modalBackground.style.backgroundColor = "rgba(0, 0, 0, 0.7)";
    modalBackground.style.left = "0px";
    modalBackground.style.opacity = "0";
    modalBackground.style.zIndex = "10";
    modalBackground.style.display = "flex";
    modalBackground.style.justifyContent = "center";
    modalBackground.style.alignItems = "center";

    let modalClone = modal.cloneNode(true);

    modalBackground.appendChild(modalClone);
    modalClone.style.display = "block";
    $(modalBackground).appendTo('#page').animate({ opacity: '1', top: '80px' }, 200);

    $(modalBackground).on('click', function (e) {
        if (e.target !== this)
            return;

        $(this).animate({ opacity: '0', top: '200px' }, 200, function () { $(this).remove(); });
    });
}

function closeModal() {
    $('.smBacker').animate({ opacity: '0', top: '200px' }, 200, function () { $('.smBacker').remove(); });
}