<?php
require_once '../app/ly-funcs.php';
$displayer = startLandery();
blabellAnalytics();
?>
<!--
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400" rel="stylesheet">
    <link rel="stylesheet" href="landing/css/master.css">
    <link rel="stylesheet" href="landing/icons/style.css">
    <script src="jquery-3.4.0.min.js"></script>   
    <?php
        //setLibrary('smothScroll', 'js');
    ?>
    <title></title>
</head>
<body>
    <img src="landing/res/background.jpg" alt="" class="background">
    <div class="filter">
        <h1 class="heading"><?php displayer(0,'lyHeading1');?></h1>  
        <div class="dwLink">
            <a class="dwLink" href="<?php displayer(0,'lyDownload',1);?>"><?php displayer(0,'lyDownload',2);?></a>
        </div>      
        <p class="description"><?php displayer(0,'lyDescription1');?></p>

        <div class="goDown">
            <a href="#p1"><span class="icon-chevron-down"></span></a>
        </div>        
    </div>
    <div class="p1" id="p1">
        <div class="tram">
            <img src="landing/res/<?php displayer(0,'lyImage');?>" alt="" class="tramImg backImg" draggable="false">
            <div class="filter2">

            </div>
        </div>
        <div class="desc">
            <h1 class="heading"><?php displayer(0,'lyHeading2');?></h1>  
            <p class="description"><?php displayer(0,'lyDescription2');?></p>
        </div>
    </div>
    <footer>
        <div class="social">
            <a href="<?php displayer(0,'lySocial',1);?>" class="socialMedia"><span class="icon-youtube"></span></a>
            <a href="<?php displayer(0,'lySocial',2);?>" class="socialMedia"><span class="icon-facebook"></span></a>
            <a href="<?php displayer(0,'lySocial',3);?>" class="socialMedia"><span class="icon-twitter"></span></a>
            <a href="<?php displayer(0,'lySocial',4);?>" class="socialMedia"><span class="icon-instagram"></span></a>
        </div>
        <div class="copy">
            <h2>© <?php displayer(0,'lyCopyright');?></h2>
            <h2>Powerd By Landery</h2>
        </div>        
    </footer>
</body>
</html>
-->